package peer_review.tests;

import static org.junit.Assert.*;

import org.junit.Test;

public class ConferenceTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
