package peer_review.models;

public class SelectArticleCommand extends Command {
	public void execute() {
		
	}
}
