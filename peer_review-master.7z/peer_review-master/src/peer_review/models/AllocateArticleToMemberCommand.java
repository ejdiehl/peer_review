package peer_review.models;

public class AllocateArticleToMemberCommand extends Command {
	public void execute() {
		
	}
}
