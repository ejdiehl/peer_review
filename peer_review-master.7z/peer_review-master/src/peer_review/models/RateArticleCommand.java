package peer_review.models;

public class RateArticleCommand extends Command {
	public void execute() {
		
	}
}
